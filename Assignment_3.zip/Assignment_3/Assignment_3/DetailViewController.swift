
/*
 Assignment - 3
 Names: Priyanka Kondapuram(z1795449), Vaishnav Gandhe(z1805765), Pruthvi Sambu(z1804923)
 Class: CSCI - 521
 Due Date: 11/08/2017
 */

//
//  DetailViewController.swift
//  Assignment_3
//
//  Created by Priyanka Kondapuram on 11/7/17.
//  Copyright © 2017 Priyanka Kondapuram. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var numberLabel: UILabel!
    @IBOutlet weak var fullDateLabel: UILabel!
    @IBOutlet weak var nickNameLabel: UILabel!
    @IBOutlet weak var politicalPartyLabel: UILabel!

    
    func configureView() {
        // Update the user interface for the detail item.
        if let detail = detailItem {
            if let label = nameLabel {
                label.text = detail.name
            }
            if let label = numberLabel {
                if(detail.number == 1 || detail.number == 21 || detail.number == 31 || detail.number == 41 || detail.number == 51) {
                    label.text = String(detail.number) + "st President of the United States"
                }
                else if(detail.number == 2 || detail.number == 22 || detail.number == 32 || detail.number == 42 || detail.number == 52) {
                    label.text = String(detail.number) + "nd President of the United States"
                }
                else if(detail.number == 3 || detail.number == 23 || detail.number == 33 || detail.number == 43 || detail.number == 53) {
                    label.text = String(detail.number) + "rd President of the United States"
                }
                else {
                    label.text = String(detail.number) + "th President of the United States"
                }
            }
            if let label = fullDateLabel {
                label.text = "(" + detail.startDate + " to " + detail.endDate + ")"
            }
            if let label = nickNameLabel {
                label.text = detail.nickName
                label.lineBreakMode = .byWordWrapping
                label.numberOfLines = 0
            }
            
            if let label = politicalPartyLabel {
                label.text = detail.politicalParty
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        configureView()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var detailItem: MCUCharacter? {
        didSet {
            // Update the view.
            configureView()
        }
    }
    
    
}


