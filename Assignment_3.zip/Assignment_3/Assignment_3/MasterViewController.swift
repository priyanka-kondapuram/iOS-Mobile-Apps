/*
 Assignment - 3
 Names: Priyanka Kondapuram(z1795449), Vaishnav Gandhe(z1805765), Pruthvi Sambu(z1804923)
 Class: CSCI - 521
 Due Date: 11/08/2017
 */


//
//  MasterViewController.swift
//  Assignment_3
//
//  Created by Priyanka Kondapuram on 11/7/17.
//  Copyright © 2017 Priyanka Kondapuram. All rights reserved.
//

import UIKit

class MasterViewController: UITableViewController, UISearchControllerDelegate, UISearchBarDelegate, UISearchResultsUpdating
{

    var detailViewController: DetailViewController? = nil
    var objects = [MCUCharacter]()
    var filteredObjects = [MCUCharacter]()
    
    let searchController = UISearchController(searchResultsController: nil)
    let searchFooter = SearchFooter(frame: CGRect(x: 0, y: 0, width: 414, height: 44))
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        navigationItem.leftBarButtonItem = editButtonItem
        
        //let addButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(insertNewObject(_:)))
        //navigationItem.rightBarButtonItem = addButton
        if let split = splitViewController {
            let controllers = split.viewControllers
            detailViewController = (controllers[controllers.count-1] as! UINavigationController).topViewController as? DetailViewController
        }
        
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        searchController.delegate = self
        definesPresentationContext = true
        tableView.tableHeaderView = searchController.searchBar
        searchController.searchBar.scopeButtonTitles = ["All", "Democ", "Feder", "DRep", "Whig", "Repub", "None"]
        searchController.searchBar.delegate = self
        
        tableView.tableFooterView = searchFooter
        
        readPropertyList()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        clearsSelectionOnViewWillAppear = splitViewController!.isCollapsed
        super.viewWillAppear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func searchBarIsEmpty() -> Bool {
        return searchController.searchBar.text?.isEmpty ?? true
    }
    
    func isFiltering() -> Bool {
        let searchBarScopeIsFiltering = searchController.searchBar.selectedScopeButtonIndex != 0
        return searchController.isActive && (!searchBarIsEmpty() || searchBarScopeIsFiltering)
    }
    
    func filterContentForSearchText(_ searchText: String, scope: String = "All") {
        
        filteredObjects = objects.filter { character in
            let doesCategoryMatch = (scope == "All") || (character.politicalParty == scope)
            
            if searchBarIsEmpty() {
                return doesCategoryMatch
            } else {
                return doesCategoryMatch && character.name.lowercased().contains(searchText.lowercased())
            }
        }
        
        tableView.reloadData()
    }
    
    // MARK: - Segues
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetail" {
            if let indexPath = tableView.indexPathForSelectedRow {
                
                let character: MCUCharacter
                if isFiltering() {
                    character = filteredObjects[indexPath.row]
                } else {
                    character = objects[indexPath.row]
                }
                
                let controller = (segue.destination as! UINavigationController).topViewController as! DetailViewController
                controller.detailItem = character
                controller.navigationItem.leftBarButtonItem = splitViewController?.displayModeButtonItem
                controller.navigationItem.leftItemsSupplementBackButton = true
            }
        }
    }
    
    @IBAction func unwindToCancel(_ segue: UIStoryboardSegue) {
        print("Cancelled")
    }
    
    /* @IBAction func unwindToSave(_ segue: UIStoryboardSegue) {
     if let addCharacterViewController = segue.source as?
     AddCharacterViewController{
     if let character = addCharacterViewController.character{
     //objects.append(character)
     //tableView.reloadData()
     
     var index = objects.index(where: {$0.name > character.name})
     if index == nil{
     index = objects.count
     }
     
     objects.insert(character, at: index!)
     
     let indexPath = IndexPath(row: index!, section: 0)
     tableView.insertRows(at: [indexPath], with: .automatic)
     }
     }
     }*/
    
    // MARK: - Table View
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isFiltering() {
            searchFooter.setIsFilteringToShow(filteredItemCount: filteredObjects.count, of: objects.count)
            return filteredObjects.count
        } else {
            searchFooter.setNotFiltering()
            return objects.count
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        let character: MCUCharacter
        if isFiltering() {
            character = filteredObjects[indexPath.row]
        } else {
            character = objects[indexPath.row]
        }
        
        cell.textLabel!.text = character.name
        cell.detailTextLabel!.text = character.politicalParty
        return cell
    }
    
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            objects.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
        }
    }
    
    func readPropertyList() {
        let plistURL = Bundle.main.url(forResource: "presidents", withExtension: ".plist")
        let array = NSArray(contentsOf: plistURL!)! as [AnyObject]
        
        for dictionary in array {
            let name = dictionary["Name"] as! String
            let number = dictionary["Number"] as! Int
            let startDate = dictionary["Start Date"] as! String
            let endDate = dictionary["End Date"] as! String
            let nickName = dictionary["Nickname"] as! String
            let politicalParty = dictionary["Political Party"] as! String
            
            objects.append(MCUCharacter(name: name, number: number, startDate: startDate, endDate: endDate, nickName: nickName, politicalParty: politicalParty))
        }
        
        objects.sort {
            return $0.number < $1.number
        }
    }
    
    func updateSearchResults(for searchController: UISearchController) {
        let searchBar = searchController.searchBar
        let scope = searchBar.scopeButtonTitles![searchBar.selectedScopeButtonIndex]
        
        filterContentForSearchText(searchController.searchBar.text!, scope: scope)
   }
    
    func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
        filterContentForSearchText(searchBar.text!, scope: searchBar.scopeButtonTitles![selectedScope])
    }
    
    
    
    
}
