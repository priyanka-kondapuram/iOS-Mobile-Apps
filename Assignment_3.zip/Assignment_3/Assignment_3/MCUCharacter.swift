/*
 Assignment - 3
 Names: Priyanka Kondapuram(z1795449), Vaishnav Gandhe(z1805765), Pruthvi Sambu(z1804923)
 Class: CSCI - 521
 Due Date: 11/08/2017
 */


//
//  MCUCharacter.swift
//  MCU
//

import Foundation

class MCUCharacter {
    var name = ""
    var number = 0
    var startDate = ""
    var endDate = ""
    var nickName = ""
    var politicalParty = ""
    
    
    init(name: String, number: Int, startDate: String, endDate: String, nickName: String, politicalParty: String) {
        self.name = name
        self.number = number
        self.startDate = startDate
        self.endDate = endDate
        self.nickName = nickName
        self.politicalParty = politicalParty
    }
}
